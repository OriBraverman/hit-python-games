# Coin Hunter - demo game for the HIT "Python for Teens" course
# Everything here is stuff we learn in the course: variables, if, loops,
# lists, dictionaries, functions, random - and pygame (lessons 22-25).
#
# Play:    python coin_hunter.py            (arrows / A D to move, SPACE or UP to jump)
# Record:  python coin_hunter.py --record   (autopilot plays and saves frames for a video)

import asyncio
import math
import os
import random
import sys

RECORD = "--record" in sys.argv
if RECORD:
    os.environ["SDL_VIDEODRIVER"] = "dummy"   # no window needed while recording

import pygame

WIDTH, HEIGHT = 960, 600
GROUND = 520
FPS = 60

SKY_TOP, SKY_BOTTOM = (214, 233, 255), (240, 247, 255)
GRASS, DIRT = (126, 200, 120), (176, 132, 92)
BLUE, NAVY, YELLOW, GOLD = (55, 118, 171), (20, 33, 61), (255, 212, 59), (201, 154, 0)
WHITE, RED, ORANGE, GRAY = (255, 255, 255), (214, 69, 69), (255, 150, 60), (150, 158, 170)

PLATFORMS = [pygame.Rect(130, 390, 190, 18), pygame.Rect(390, 315, 180, 18), pygame.Rect(650, 390, 190, 18)]

pygame.init()
screen = pygame.display.set_mode((WIDTH, HEIGHT))
pygame.display.set_caption("Coin Hunter")
clock = pygame.time.Clock()
font_big = pygame.font.SysFont("segoeui", 64, bold=True)
font = pygame.font.SysFont("segoeui", 28, bold=True)
font_small = pygame.font.SysFont("segoeui", 20)


def new_game():
    return {
        "player": {"x": WIDTH / 2, "y": GROUND - 46, "vx": 0, "vy": 0, "on_ground": True, "hurt": 0},
        "coins": [new_coin() for _ in range(5)],
        "meteors": [],
        "particles": [],
        "score": 0,
        "lives": 3,
        "level": 1,
        "timer": 0,
        "state": "play",
    }


def new_coin():
    if random.random() < 0.5:
        p = random.choice(PLATFORMS)
        return {"x": random.randint(p.left + 20, p.right - 20), "y": p.top - 30}
    return {"x": random.randint(40, WIDTH - 40), "y": random.randint(GROUND - 140, GROUND - 30)}


def new_meteor(level):
    return {"x": random.randint(30, WIDTH - 30), "y": -40, "speed": random.uniform(3, 4.5) + level * 0.7,
            "r": random.randint(16, 26)}


def burst(game, x, y, color, n=14):
    for _ in range(n):
        angle = random.uniform(0, 2 * math.pi)
        speed = random.uniform(2, 6)
        game["particles"].append({"x": x, "y": y, "vx": math.cos(angle) * speed, "vy": math.sin(angle) * speed,
                                  "life": 30, "color": color})


def autopilot(game):
    """A simple 'bot' used for recording the demo video."""
    p = game["player"]
    bot = game.setdefault("bot", {"target": None, "frames": 0, "skip": []})
    choices = [c for c in game["coins"] if c not in bot["skip"]] or game["coins"]
    target = min(choices, key=lambda c: abs(c["x"] - p["x"]) + abs(c["y"] - p["y"]) * 0.6)
    if target is bot["target"]:
        bot["frames"] += 1
        if bot["frames"] > 150:                     # stuck on this coin -> try another one
            bot["skip"] = [target]
    else:
        bot["target"], bot["frames"] = target, 0
    move = 0
    if target["x"] > p["x"] + 10:
        move = 1
    elif target["x"] < p["x"] - 10:
        move = -1
    for m in game["meteors"]:                       # dodge meteors coming down near us
        if m["y"] > 200 and abs(m["x"] - p["x"]) < 90:
            move = 1 if m["x"] < p["x"] else -1
    jump = target["y"] < p["y"] - 40 and abs(target["x"] - p["x"]) < 140
    return move, jump


def update(game, move, jump):
    p = game["player"]
    p["vx"] = move * 6
    if jump and p["on_ground"]:
        p["vy"] = -18
    p["vy"] += 0.8                                   # gravity
    p["x"] = max(20, min(WIDTH - 20, p["x"] + p["vx"]))
    old_bottom = p["y"] + 23
    p["y"] += p["vy"]
    p["on_ground"] = False
    if p["y"] + 23 >= GROUND:                        # land on the ground
        p["y"], p["vy"], p["on_ground"] = GROUND - 23, 0, True
    for plat in PLATFORMS:                           # land on a platform (only when falling)
        if p["vy"] >= 0 and plat.left < p["x"] < plat.right and old_bottom <= plat.top <= p["y"] + 23:
            p["y"], p["vy"], p["on_ground"] = plat.top - 23, 0, True

    body = pygame.Rect(p["x"] - 23, p["y"] - 23, 46, 46)
    for c in game["coins"][:]:
        if body.colliderect(pygame.Rect(c["x"] - 14, c["y"] - 14, 28, 28)):
            game["coins"].remove(c)
            game["coins"].append(new_coin())
            game["score"] += 10
            burst(game, c["x"], c["y"], YELLOW)
            if game["score"] % 100 == 0:
                game["level"] += 1

    game["timer"] += 1
    if game["timer"] % max(25, 70 - game["level"] * 8) == 0:
        game["meteors"].append(new_meteor(game["level"]))
    for m in game["meteors"][:]:
        m["y"] += m["speed"]
        if p["hurt"] == 0 and math.hypot(m["x"] - p["x"], m["y"] - p["y"]) < m["r"] + 20:
            game["meteors"].remove(m)
            game["lives"] -= 1
            p["hurt"] = 60
            burst(game, m["x"], m["y"], ORANGE, 24)
            if game["lives"] == 0:
                game["state"] = "over"
        elif m["y"] > GROUND:
            game["meteors"].remove(m)
            burst(game, m["x"], GROUND, GRAY, 8)
    if p["hurt"] > 0:
        p["hurt"] -= 1

    for pt in game["particles"][:]:
        pt["x"] += pt["vx"]
        pt["y"] += pt["vy"]
        pt["vy"] += 0.25
        pt["life"] -= 1
        if pt["life"] <= 0:
            game["particles"].remove(pt)


def draw_background():
    for y in range(0, GROUND, 4):                    # sky gradient
        t = y / GROUND
        color = [int(SKY_TOP[i] + (SKY_BOTTOM[i] - SKY_TOP[i]) * t) for i in range(3)]
        pygame.draw.rect(screen, color, (0, y, WIDTH, 4))
    for x, y, s in [(120, 90, 1.0), (420, 60, 0.8), (760, 110, 1.2)]:   # clouds
        for dx, dy, r in [(0, 0, 28), (30, -12, 34), (64, 0, 26)]:
            pygame.draw.circle(screen, WHITE, (int(x + dx * s), int(y + dy * s)), int(r * s))
    pygame.draw.rect(screen, DIRT, (0, GROUND, WIDTH, HEIGHT - GROUND))
    pygame.draw.rect(screen, GRASS, (0, GROUND, WIDTH, 16))
    for plat in PLATFORMS:
        pygame.draw.rect(screen, DIRT, plat, border_radius=8)
        pygame.draw.rect(screen, GRASS, (plat.x, plat.y, plat.width, 8), border_radius=8)


def draw_player(p, t):
    if p["hurt"] and (p["hurt"] // 5) % 2 == 0:      # blink after a hit
        return
    x, y = int(p["x"]), int(p["y"])
    squash = 4 if not p["on_ground"] else 0
    pygame.draw.rect(screen, BLUE, (x - 23, y - 23 - squash, 46, 46 + squash), border_radius=12)
    look = 4 if p["vx"] > 0 else (-4 if p["vx"] < 0 else 0)
    for ex in (-9, 9):
        pygame.draw.circle(screen, WHITE, (x + ex + look, y - 6), 7)
        pygame.draw.circle(screen, NAVY, (x + ex + look + 2, y - 5), 3)
    pygame.draw.rect(screen, YELLOW, (x - 23, y + 8, 46, 6))   # belt


def draw_coin(c, t):
    w = abs(math.sin(t / 10 + c["x"])) * 13 + 3                   # spinning coin
    y = c["y"] + math.sin(t / 15 + c["x"]) * 4
    pygame.draw.ellipse(screen, GOLD, (c["x"] - w, y - 14, w * 2, 28))
    pygame.draw.ellipse(screen, YELLOW, (c["x"] - w + 3, y - 11, max(1, w * 2 - 6), 22))


def draw_meteor(m):
    for i in range(5):                                           # fire trail
        pygame.draw.circle(screen, ORANGE, (int(m["x"]), int(m["y"] - i * 9)), max(2, m["r"] - i * 4))
    pygame.draw.circle(screen, GRAY, (int(m["x"]), int(m["y"])), m["r"])
    pygame.draw.circle(screen, (120, 128, 140), (int(m["x"] - m["r"] / 3), int(m["y"] - m["r"] / 4)), m["r"] // 3)
    pygame.draw.ellipse(screen, (90, 140, 90), (m["x"] - m["r"], GROUND - 4, m["r"] * 2, 8))   # shadow


def draw_hud(game):
    screen.blit(font.render(f"Score: {game['score']}", True, NAVY), (20, 14))
    screen.blit(font_small.render(f"Level {game['level']}", True, NAVY), (22, 50))
    for i in range(3):
        color = RED if i < game["lives"] else (200, 205, 215)
        x = WIDTH - 40 - i * 38
        pygame.draw.circle(screen, color, (x - 7, 30), 9)
        pygame.draw.circle(screen, color, (x + 7, 30), 9)
        pygame.draw.polygon(screen, color, [(x - 16, 33), (x + 16, 33), (x, 50)])


def draw_center(lines):
    shade = pygame.Surface((WIDTH, HEIGHT), pygame.SRCALPHA)
    shade.fill((255, 255, 255, 170))
    screen.blit(shade, (0, 0))
    y = HEIGHT / 2 - 70
    for text, f, color in lines:
        img = f.render(text, True, color)
        screen.blit(img, (WIDTH / 2 - img.get_width() / 2, y))
        y += img.get_height() + 10


def draw(game, t):
    draw_background()
    for c in game["coins"]:
        draw_coin(c, t)
    for m in game["meteors"]:
        draw_meteor(m)
    for pt in game["particles"]:
        pygame.draw.circle(screen, pt["color"], (int(pt["x"]), int(pt["y"])), max(1, pt["life"] // 6))
    draw_player(game["player"], t)
    draw_hud(game)


async def main():
    random.seed(7 if RECORD else None)
    game = new_game()
    game["state"] = "start"
    t = 0
    frames_dir = os.path.join(os.path.dirname(os.path.abspath(__file__)), "frames")
    if RECORD:
        os.makedirs(frames_dir, exist_ok=True)
    while True:
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                pygame.quit()
                return
            if event.type == pygame.KEYDOWN and event.key == pygame.K_SPACE and game["state"] != "play" or event.type == pygame.MOUSEBUTTONDOWN and game["state"] != "play":
                game = new_game()

        keys = pygame.key.get_pressed()
        if RECORD:
            if game["state"] == "start" and t > 90:
                game = new_game()
            move, jump = autopilot(game) if game["state"] == "play" else (0, False)
        else:
            move = (keys[pygame.K_RIGHT] or keys[pygame.K_d]) - (keys[pygame.K_LEFT] or keys[pygame.K_a])
            jump = keys[pygame.K_SPACE] or keys[pygame.K_UP] or keys[pygame.K_w]
            if pygame.mouse.get_pressed()[0]:                      # touch / mouse: hold beside the player to walk, above to jump
                mx, my = pygame.mouse.get_pos(); p = game["player"]
                move = 1 if mx > p["x"] + 30 else -1 if mx < p["x"] - 30 else 0
                jump = jump or my < p["y"] - 60

        if game["state"] == "play":
            update(game, move, jump)
        draw(game, t)
        if game["state"] == "start":
            draw_center([("Coin Hunter", font_big, BLUE), ("Collect coins. Dodge meteors.", font, NAVY),
                         ("Press SPACE or tap to start", font_small, NAVY)])
        elif game["state"] == "over":
            draw_center([("Game Over", font_big, RED), (f"Score: {game['score']}", font, NAVY),
                         ("Press SPACE or tap to play again", font_small, NAVY)])
        pygame.display.flip()
        await asyncio.sleep(0)

        if RECORD:
            if t % 2 == 0:                                        # 30 fps video
                pygame.image.save(screen, os.path.join(frames_dir, f"f{t // 2:04d}.png"))
            if t >= 60 * 20:                                      # 20 seconds
                pygame.quit()
                return
        else:
            clock.tick(FPS)
        t += 1


asyncio.run(main())
